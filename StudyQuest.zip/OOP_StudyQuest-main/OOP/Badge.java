public class Badge {

    private final String name;

    public Badge(String name) {
        this.name = name.trim();
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return name;
    }
}