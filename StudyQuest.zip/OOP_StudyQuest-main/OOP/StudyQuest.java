import java.util.Scanner;
import java.util.ArrayList;

public class StudyQuest {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        printHeader();
        System.out.print("Enter your name: ");
        String name = sc.nextLine().trim();

        if (name.isEmpty()) {
            name = "Player";
            System.out.println("Using default name: Player");
        }

        User user = new User(name);

        if (FileManager.playerExists(name)) {
            System.out.println("Welcome back, " + name + "!");
            loadPlayerData(user, name);
        } else {
            System.out.println("New player created: " + name);
        }

        int choice;
        do {
            showMainMenu();
            choice = getValidInt(sc, "Choose: ", 1, 11);
            handleMenuChoice(choice, user, name, sc);
        } while (choice != 11);

        sc.close();
    }

    private static void loadPlayerData(User user, String name) {
        user.loadTasks(FileManager.loadTasks(name));
        user.loadBadges(FileManager.loadBadges(name));
        user.loadCategories(FileManager.loadCategories(name));
        
        int[] stats = FileManager.loadUserStats(name);
        user.setStats(stats[0], stats[1]);
        user.recalculateProgress();
    }

    private static void showMainMenu() {
        System.out.println("\n===== MAIN MENU =====");
        System.out.println("1. Add Task");
        System.out.println("2. View Tasks");
        System.out.println("3. Complete Task");
        System.out.println("4. Delete Task");
        System.out.println("5. Show Stats");
        System.out.println("6. Show Badges");
        System.out.println("7. Show Categories");
        System.out.println("8. Create Custom Category");
        System.out.println("9. Delete Category");
        System.out.println("10. Save Progress");
        System.out.println("11. Exit");
    }

    private static void handleMenuChoice(int choice, User user, String name, Scanner sc) {
        switch (choice) {
            case 1 -> addTask(user, sc);
            case 2 -> user.showTasks();
            case 3 -> completeTask(user, sc);
            case 4 -> deleteTask(user, sc);
            case 5 -> user.showStats();
            case 6 -> user.showBadges();
            case 7 -> user.showCategories();
            case 8 -> createCustomCategory(user, sc);
            case 9 -> deleteCategory(user, sc);
            case 10 -> saveAllProgress(user, name);
            case 11 -> {
                saveAllProgress(user, name);
                System.out.println("Progress saved. Goodbye!");
            }
            default -> System.out.println("Invalid choice.");
        }
    }

    private static int getValidInt(Scanner sc, String prompt, int min, int max) {
        while (true) {
            System.out.print(prompt);
            try {
                int input = sc.nextInt();
                sc.nextLine();
                if (input >= min && input <= max) return input;
                System.out.println("Please enter a number between " + min + " and " + max + ".");
            } catch (Exception e) {
                sc.nextLine();
                System.out.println("Invalid input. Please enter a number.");
            }
        }
    }

    private static void addTask(User user, Scanner sc) {
        System.out.print("Enter task title: ");
        String title = sc.nextLine().trim();

        if (title.isEmpty()) {
            System.out.println("Task title cannot be empty!");
            return;
        }

        user.showCategories();
        int catChoice = getValidInt(sc, "Enter category number (0 to cancel): ", 0, user.getCategories().size());

        if (catChoice == 0) {
            System.out.println("Task creation cancelled.");
            return;
        }

        Category selected = user.getCategories().get(catChoice - 1);
        user.addTask(title, selected.getName(), selected.getXpReward());
        System.out.println("✓ Task added successfully! Reward: +" + selected.getXpReward() + " XP");
    }

    private static void completeTask(User user, Scanner sc) {
        user.showTasks();
        if (user.getTasks().isEmpty()) return;

        System.out.print("Enter task number to complete (0 to cancel): ");
        int taskNum = getValidInt(sc, "", 0, user.getTasks().size());   // Updated

        if (taskNum == 0) {
            System.out.println("Task completion cancelled.");
            return;
        }

        user.completeTask(taskNum - 1);
    }

    private static void deleteTask(User user, Scanner sc) {
        user.showTasks();
        if (user.getTasks().isEmpty()) return;

        int taskNum = getValidInt(sc, "Enter task number to delete (0 to cancel): ", 0, user.getTasks().size());
        if (taskNum == 0) {
            System.out.println("Deletion cancelled.");
            return;
        }
        if (user.deleteTask(taskNum - 1)) {
            System.out.println("✓ Task deleted successfully!");
        }
    }

    private static void createCustomCategory(User user, Scanner sc) {
        System.out.print("Enter category name: ");
        String catName = sc.nextLine().trim();

        if (catName.isEmpty()) {
            System.out.println("Category name cannot be empty!");
            return;
        }

        System.out.println("Select difficulty:");
        System.out.println("1. Easy (+20 XP)");
        System.out.println("2. Medium (+50 XP)");
        System.out.println("3. Hard (+100 XP)");
        System.out.println("0. Cancel");

        int diff = getValidInt(sc, "Enter difficulty: ", 0, 3);

        String difficulty = switch (diff) {
            case 1 -> "Easy";
            case 2 -> "Medium";
            case 3 -> "Hard";
            default -> "";
        };

        if (!difficulty.isEmpty()) {
            user.addCategory(catName, difficulty);
            System.out.println("✓ Category '" + catName + "' (" + difficulty + ") created!");
        } else {
            System.out.println("Category creation cancelled.");
        }
    }

    private static void deleteCategory(User user, Scanner sc) {
        user.showCategories();
        if (user.getCategories().isEmpty()) return;

        int catNum = getValidInt(sc, "Enter category number to delete (0 to cancel): ", 0, user.getCategories().size());
        if (catNum == 0) {
            System.out.println("Deletion cancelled.");
            return;
        }
        if (user.deleteCategory(catNum - 1)) {
            System.out.println("✓ Category deleted successfully!");
        }
    }

    private static void saveAllProgress(User user, String name) {
        FileManager.saveTasks(user.getTasks(), name);
        FileManager.saveUserStats(name, user.getXP(), user.getLevel());
        FileManager.saveBadges(user.getBadges(), name);
        FileManager.saveCategories(user.getCategories(), name);
        System.out.println("All progress saved successfully!");
    }

    private static void printHeader() {
        System.out.println("=========================");
        System.out.println("      STUDY QUEST");
        System.out.println("=========================");
    }
}