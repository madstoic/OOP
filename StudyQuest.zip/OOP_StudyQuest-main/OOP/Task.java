public class Task {

    private final String title;
    private final String category;
    private final int xp;
    private boolean completed;

    public Task(String title, String category, int xp) {
        this.title = title.trim();
        this.category = category.trim();
        this.xp = xp;
        this.completed = false;
    }

    public void markDone() {
        this.completed = true;
    }

    public boolean isDone() {
        return completed;
    }

    public int getXP() {
        return xp;
    }

    public String getTitle() {
        return title;
    }

    public String getCategory() {
        return category;
    }

    public String toFileString() {
        return title + "|" + category + "|" + xp + "|" + completed;
    }
}