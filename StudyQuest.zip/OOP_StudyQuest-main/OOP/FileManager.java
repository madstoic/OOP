import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class FileManager {

    private static final String DELIMITER = "|";

    // ==================== SAVE METHODS ====================

    public static void saveTasks(ArrayList<Task> tasks, String playerName) {
        saveToFile(playerName + "_tasks.txt", tasks, task -> 
            task.getTitle() + DELIMITER + task.getCategory() + DELIMITER + 
            task.getXP() + DELIMITER + task.isDone());
    }

    public static void saveBadges(ArrayList<Badge> badges, String playerName) {
        saveToFile(playerName + "_badges.txt", badges, Badge::getName);
    }

    public static void saveUserStats(String playerName, int xp, int level) {
        saveToFile(playerName + "_stats.txt", xp + DELIMITER + level);
    }

    public static void saveCategories(ArrayList<Category> categories, String playerName) {
        saveToFile(playerName + "_categories.txt", categories, Category::toFileString);
    }

    private static <T> void saveToFile(String filename, ArrayList<T> items, java.util.function.Function<T, String> mapper) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(filename))) {
            for (T item : items) {
                writer.println(mapper.apply(item));
            }
        } catch (IOException e) {
            System.err.println("Error saving to " + filename + ": " + e.getMessage());
        }
    }

    private static void saveToFile(String filename, String content) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(filename))) {
            writer.println(content);
        } catch (IOException e) {
            System.err.println("Error saving to " + filename + ": " + e.getMessage());
        }
    }

    // ==================== LOAD METHODS ====================

    public static ArrayList<Task> loadTasks(String playerName) {
        ArrayList<Task> tasks = new ArrayList<>();
        File file = new File(playerName + "_tasks.txt");
        if (!file.exists()) return tasks;

        try (Scanner reader = new Scanner(file)) {
            while (reader.hasNextLine()) {
                String line = reader.nextLine().trim();
                if (line.isEmpty()) continue;

                String[] parts = line.split("\\|");
                if (parts.length >= 4) {
                    String title = parts[0];
                    String category = parts[1];
                    int xp = Integer.parseInt(parts[2]);
                    boolean done = Boolean.parseBoolean(parts[3]);

                    Task task = new Task(title, category, xp);
                    if (done) task.markDone();
                    tasks.add(task);
                }
            }
        } catch (Exception e) {
            System.err.println("Error loading tasks: " + e.getMessage());
        }
        return tasks;
    }

    public static ArrayList<Badge> loadBadges(String playerName) {
        ArrayList<Badge> badges = new ArrayList<>();
        File file = new File(playerName + "_badges.txt");
        if (!file.exists()) return badges;

        try (Scanner reader = new Scanner(file)) {
            while (reader.hasNextLine()) {
                String line = reader.nextLine().trim();
                if (!line.isEmpty()) {
                    badges.add(new Badge(line));
                }
            }
        } catch (Exception e) {
            System.err.println("Error loading badges: " + e.getMessage());
        }
        return badges;
    }

    public static int[] loadUserStats(String playerName) {
        int[] stats = {0, 0}; // xp, level
        File file = new File(playerName + "_stats.txt");
        if (!file.exists()) return stats;

        try (Scanner reader = new Scanner(file)) {
            if (reader.hasNextLine()) {
                String[] parts = reader.nextLine().trim().split("\\|");
                if (parts.length >= 2) {
                    stats[0] = Integer.parseInt(parts[0]);
                    stats[1] = Integer.parseInt(parts[1]);
                }
            }
        } catch (Exception e) {
            System.err.println("Error loading stats: " + e.getMessage());
        }
        return stats;
    }

    public static ArrayList<Category> loadCategories(String playerName) {
        ArrayList<Category> categories = new ArrayList<>();
        File file = new File(playerName + "_categories.txt");
        if (!file.exists()) return categories;

        try (Scanner reader = new Scanner(file)) {
            while (reader.hasNextLine()) {
                String line = reader.nextLine().trim();
                if (line.isEmpty()) continue;

                String[] parts = line.split("\\|");
                if (parts.length >= 2) {
                    categories.add(new Category(parts[0], parts[1]));
                }
            }
        } catch (Exception e) {
            System.err.println("Error loading categories: " + e.getMessage());
        }
        return categories;
    }

    public static boolean playerExists(String playerName) {
        return new File(playerName + "_tasks.txt").exists();
    }
}