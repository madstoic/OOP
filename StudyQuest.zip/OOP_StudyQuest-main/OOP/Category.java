public class Category {

    private final String name;
    private final String difficulty;
    private final int xpReward;

    public Category(String name, String difficulty) {
        this.name = name.trim();
        this.difficulty = difficulty.trim();
        this.xpReward = calculateXP(this.difficulty);
    }

    private int calculateXP(String difficulty) {
        return switch (difficulty.toLowerCase()) {
            case "easy" -> 20;
            case "medium" -> 50;
            case "hard" -> 100;
            default -> 30;
        };
    }

    public String getName() {
        return name;
    }

    public String getDifficulty() {
        return difficulty;
    }

    public int getXpReward() {
        return xpReward;
    }

    public String toFileString() {
        return name + "|" + difficulty + "|" + xpReward;
    }
}