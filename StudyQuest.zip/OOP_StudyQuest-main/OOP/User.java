import java.util.ArrayList;

public class User {

    private final String name;
    private int xp;
    private int level;

    private ArrayList<Task> tasks;
    private ArrayList<Badge> badges;
    private ArrayList<Category> categories;

    public User(String name) {
        this.name = name.trim();
        this.xp = 0;
        this.level = 0;

        tasks = new ArrayList<>();
        badges = new ArrayList<>();
        categories = new ArrayList<>();

        // Default Categories
        categories.add(new Category("School", "Medium"));
        categories.add(new Category("Personal", "Easy"));
        categories.add(new Category("Fitness", "Medium"));
        categories.add(new Category("Review", "Medium"));
        categories.add(new Category("Assignment", "Hard"));
    }

    public void addTask(String title, String category, int xpReward) {
        tasks.add(new Task(title, category, xpReward));
    }

    public boolean deleteTask(int index) {
        if (index < 0 || index >= tasks.size()) return false;
        tasks.remove(index);
        return true;
    }

    public void completeTask(int index) {
        if (index < 0 || index >= tasks.size()) {
            System.out.println("Invalid task number.");
            return;
        }

        Task task = tasks.get(index);
        if (!task.isDone()) {
            task.markDone();
            xp += task.getXP();

            System.out.println("Task completed! +" + task.getXP() + " XP");
            checkLevelUp();
            checkBadges();
        } else {
            System.out.println("Task already completed.");
        }
    }

    private void checkLevelUp() {
        int newLevel = xp / 100;
        if (newLevel > level) {
            level = newLevel;
            System.out.println("\n================================");
            System.out.println("LEVEL UP! You are now Level " + level);
            System.out.println("================================\n");
        }
    }

    private void checkBadges() {
        long completedCount = tasks.stream().filter(Task::isDone).count();

        addBadgeIfNotExists(completedCount >= 1, "First Step");
        addBadgeIfNotExists(completedCount >= 5, "Task Beginner");
        addBadgeIfNotExists(completedCount >= 10, "Focused Student");
        addBadgeIfNotExists(completedCount >= 20, "Study Master");
    }

    private void addBadgeIfNotExists(boolean condition, String badgeName) {
        if (condition && !hasBadge(badgeName)) {
            badges.add(new Badge(badgeName));
            System.out.println("NEW BADGE UNLOCKED: " + badgeName);
        }
    }

    private boolean hasBadge(String badgeName) {
        return badges.stream().anyMatch(b -> b.getName().equals(badgeName));
    }

    public void recalculateProgress() {
        xp = tasks.stream()
                .filter(Task::isDone)
                .mapToInt(Task::getXP)
                .sum();
        level = xp / 100;
        checkBadges();
    }

    // ==================== IMPROVED BADGE DISPLAY ====================

    public void showBadges() {
        long completedCount = tasks.stream().filter(Task::isDone).count();

        System.out.println("\n=================================");
        System.out.println("YOUR BADGE COLLECTION");
        System.out.println("=================================");

        showBadgeStatus("First Step", "Complete your first task", 1, completedCount);
        showBadgeStatus("Task Beginner", "Complete 5 tasks", 5, completedCount);
        showBadgeStatus("Focused Student", "Complete 10 tasks", 10, completedCount);
        showBadgeStatus("Study Master", "Complete 20 tasks", 20, completedCount);

        System.out.println("=================================");
        System.out.println("Total Tasks Completed: " + completedCount);
        System.out.println("Keep going! More badges await!");
    }

    private void showBadgeStatus(String badgeName, String description, int requirement, long completedCount) {
        boolean unlocked = hasBadge(badgeName);

        if (unlocked) {
            System.out.println("[UNLOCKED] " + badgeName);
            System.out.println("   " + description);
            System.out.println("   Status: UNLOCKED");
            System.out.println();
        } else {
            System.out.println("[LOCKED] " + badgeName);
            System.out.println("   " + description);
            System.out.println("   Progress: " + completedCount + "/" + requirement + " tasks");
            System.out.println("   Status: Locked");
            System.out.println();
        }
    }

    public void showTasks() {
        if (tasks.isEmpty()) {
            System.out.println("No tasks available.");
            return;
        }
        System.out.println("\n===== TASK LIST =====");
        for (int i = 0; i < tasks.size(); i++) {
            Task t = tasks.get(i);
            System.out.printf("%d. %s | Category: %s%s%n", 
                i + 1, t.getTitle(), t.getCategory(), t.isDone() ? " [DONE]" : "");
        }
    }

    public void showStats() {
        System.out.println("\n===== PLAYER STATS =====");
        System.out.println("Name: " + name);
        System.out.println("XP: " + xp);
        System.out.println("Level: " + level);
        System.out.println("Progress: " + (xp % 100) + "/100");
    }

    public void showCategories() {
        System.out.println("\n===== AVAILABLE CATEGORIES =====");
        for (int i = 0; i < categories.size(); i++) {
            Category c = categories.get(i);
            System.out.printf("%d. %s (%s) - %d XP%n", 
                i + 1, c.getName(), c.getDifficulty(), c.getXpReward());
        }
    }

    public void addCategory(String name, String difficulty) {
        categories.add(new Category(name, difficulty));
    }

    public boolean deleteCategory(int index) {
        if (index < 0 || index >= categories.size()) return false;
        categories.remove(index);
        return true;
    }

    public ArrayList<Task> getTasks() { return tasks; }
    public ArrayList<Badge> getBadges() { return badges; }
    public ArrayList<Category> getCategories() { return categories; }

    public void loadTasks(ArrayList<Task> loaded) { this.tasks = loaded; }
    public void loadBadges(ArrayList<Badge> loaded) { this.badges = loaded; }
    public void loadCategories(ArrayList<Category> loaded) { this.categories = loaded; }

    public void setStats(int xp, int level) {
        this.xp = xp;
        this.level = level;
    }

    public int getXP() { return xp; }
    public int getLevel() { return level; }
}