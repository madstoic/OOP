import java.io.*;
import java.util.ArrayList;

public class FileManager {

    public static void saveTasks(ArrayList<Task> tasks) {
        try {
            PrintWriter writer = new PrintWriter("tasks.txt");

            for (Task t : tasks) {
                writer.println(t.toFileString());
            }

            writer.close();
            System.out.println("Tasks saved successfully.");
        } catch (Exception e) {
            System.out.println("Error saving file.");
        }
    }

    public static ArrayList<Task> loadTasks() {
        ArrayList<Task> tasks = new ArrayList<>();
        try {
            File file = new File("tasks.txt");
            if (!file.exists()) {
                return tasks;
            }

            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;

            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 4) {
                    String title = parts[0];
                    String category = parts[1];
                    int xp = Integer.parseInt(parts[2]);
                    boolean completed = Boolean.parseBoolean(parts[3]);

                    Task task = new Task(title, category, xp);
                    if (completed) {
                        task.markDone();
                    }
                    tasks.add(task);
                }
            }
            reader.close();
        } catch (Exception e) {
            // Silent - no previous save file
        }
        return tasks;
    }
}