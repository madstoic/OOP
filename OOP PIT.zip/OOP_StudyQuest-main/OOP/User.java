import java.util.ArrayList;

public class User {

    private String name;
    private int xp;
    private int level;

    private ArrayList<Task> tasks;
    private ArrayList<Badge> badges;

    // CONSTRUCTOR
    public User(String name) {
        this.name = name;
        xp = 0;
        level = 1;

        tasks = new ArrayList<>();
        badges = new ArrayList<>();
    }

    // ADD TASK
    public void addTask(String title, String category, int xpReward) {
        tasks.add(new Task(title, category, xpReward));
    }

    // DELETE TASK
    public void deleteTask(int index) {
        if (index < 0 || index >= tasks.size()) {
            System.out.println("Invalid task number.");
            return;
        }
        System.out.println("Deleted: " + tasks.get(index).getTitle());
        tasks.remove(index);
    }

    // SHOW TASKS
    public void showTasks() {
        if (tasks.isEmpty()) {
            System.out.println("No tasks available.");
            return;
        }

        System.out.println("\n===== TASK LIST =====");
        for (int i = 0; i < tasks.size(); i++) {
            Task t = tasks.get(i);
            System.out.print((i + 1) + ". " + t.getTitle());
            System.out.print(" | Category: " + t.getCategory());
            if (t.isDone()) System.out.print(" [DONE]");
            System.out.println();
        }
    }

    // COMPLETE TASK
    public void completeTask(int index) {
        if (index < 0 || index >= tasks.size()) {
            System.out.println("Invalid task number.");
            return;
        }

        Task t = tasks.get(index);

        if (!t.isDone()) {
            t.markDone();
            xp += t.getXP();
            System.out.println("Task completed! +" + t.getXP() + " XP");
            checkLevelUp();
            checkBadges();
        } else {
            System.out.println("Task already completed.");
        }
    }

    private void checkLevelUp() {
        int newLevel = (xp / 100) + 1;
        if (newLevel > level) {
            level = newLevel;
            System.out.println("================================");
            System.out.println("LEVEL UP! You are now Level " + level);
            System.out.println("================================");
        }
    }

    private void checkBadges() {
        int completedCount = 0;
        for (Task t : tasks) {
            if (t.isDone()) completedCount++;
        }

        if (completedCount >= 1 && !hasBadge("First Step")) {
            badges.add(new Badge("First Step"));
            System.out.println("NEW BADGE UNLOCKED: First Step");
        }
        if (completedCount >= 5 && !hasBadge("Task Beginner")) {
            badges.add(new Badge("Task Beginner"));
            System.out.println("NEW BADGE UNLOCKED: Task Beginner");
        }
        if (completedCount >= 10 && !hasBadge("Focused Student")) {
            badges.add(new Badge("Focused Student"));
            System.out.println("NEW BADGE UNLOCKED: Focused Student");
        }
        if (completedCount >= 20 && !hasBadge("Study Master")) {
            badges.add(new Badge("Study Master"));
            System.out.println("NEW BADGE UNLOCKED: Study Master");
        }
    }

    private boolean hasBadge(String badgeName) {
        for (Badge b : badges) {
            if (b.getName().equals(badgeName)) return true;
        }
        return false;
    }

    // SHOW BADGES - Clean & Compatible Version
    public void showBadges() {
        System.out.println("\n=================================");
        System.out.println("       YOUR BADGE COLLECTION");
        System.out.println("=================================");

        int completedCount = 0;
        for (Task t : tasks) {
            if (t.isDone()) completedCount++;
        }

        displayBadge("First Step", "Complete your first task", 1, completedCount);
        displayBadge("Task Beginner", "Complete 5 tasks", 5, completedCount);
        displayBadge("Focused Student", "Complete 10 tasks", 10, completedCount);
        displayBadge("Study Master", "Complete 20 tasks", 20, completedCount);

        System.out.println("=================================");
        System.out.println("Total Tasks Completed: " + completedCount);
        System.out.println("Keep going! More badges await!");
    }

    private void displayBadge(String name, String description, int requirement, int completed) {
        boolean unlocked = completed >= requirement;

        if (unlocked) {
            System.out.println("[UNLOCKED] " + name);
            System.out.println("   " + description);
            System.out.println("   Status: UNLOCKED\n");
        } else {
            System.out.println("[LOCKED] " + name);
            System.out.println("   " + description);
            System.out.println("   Progress: " + completed + "/" + requirement + " tasks");
            System.out.println("   Status: Locked\n");
        }
    }

    public void showStats() {
        System.out.println("\n===== PLAYER STATS =====");
        System.out.println("Name: " + name);
        System.out.println("XP: " + xp);
        System.out.println("Level: " + level);
        System.out.println("Progress to next level: " + (xp % 100) + "/100");
    }

    public ArrayList<Task> getTasks() {
        return tasks;
    }

    public void recalculateStats() {
        xp = 0;
        for (Task t : tasks) {
            if (t.isDone()) {
                xp += t.getXP();
            }
        }
        level = (xp / 100) + 1;
    }
}