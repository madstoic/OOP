import java.util.Scanner;
import java.util.ArrayList;

public class StudyQuest {

    static Scanner sc = new Scanner(System.in);

    public static int getInt() {
        try {
            int number = Integer.parseInt(sc.nextLine().trim());
            return number;
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    public static void main(String[] args) {

        System.out.println("=========================");
        System.out.println("      STUDY QUEST");
        System.out.println("=========================");

        System.out.print("Enter your name: ");
        String name = sc.nextLine().trim();

        if (name.isEmpty()) {
            name = "Student";
            System.out.println("No name entered. Using default: Student");
        }

        User user = new User(name);

        // Load saved tasks
        ArrayList<Task> loadedTasks = FileManager.loadTasks();
        for (Task t : loadedTasks) {
            user.getTasks().add(t);
        }
        user.recalculateStats();

        if (!loadedTasks.isEmpty()) {
            System.out.println("Previous tasks loaded successfully!");
        }

        int choice;

        do {
            System.out.println("\n===== MAIN MENU =====");
            System.out.println("1. Add Task");
            System.out.println("2. View Tasks");
            System.out.println("3. Complete Task");
            System.out.println("4. Delete Task");
            System.out.println("5. Show Stats");
            System.out.println("6. Show Badges");
            System.out.println("7. Save Tasks");
            System.out.println("8. Exit");

            System.out.print("Choose: ");
            choice = getInt();

            if (choice == -1) {
                System.out.println("Invalid input. Please enter a number.");
                continue;
            }

            switch (choice) {

                case 1: // Add Task
                    System.out.print("Enter task title: ");
                    String title = sc.nextLine().trim();

                    if (title.isEmpty()) {
                        System.out.println("Task title cannot be empty.");
                        break;
                    }

                    // Check duplicate
                    boolean duplicate = false;
                    for (Task t : user.getTasks()) {
                        if (t.getTitle().equalsIgnoreCase(title)) {
                            duplicate = true;
                            break;
                        }
                    }
                    if (duplicate) {
                        System.out.println("Task with this title already exists!");
                        break;
                    }

                    System.out.println("Choose Category:");
                    System.out.println("1. School (+50 XP)");
                    System.out.println("2. Personal (+20 XP)");
                    System.out.println("3. Fitness (+30 XP)");
                    System.out.println("4. Review (+40 XP)");
                    System.out.println("5. Assignment (+60 XP)");

                    System.out.print("Enter choice: ");
                    int cat = getInt();

                    if (cat < 1 || cat > 5) {
                        System.out.println("Invalid category.");
                        break;
                    }

                    String category = "";
                    int xp = 0;
                    switch (cat) {
                        case 1: category = "School"; xp = 50; break;
                        case 2: category = "Personal"; xp = 20; break;
                        case 3: category = "Fitness"; xp = 30; break;
                        case 4: category = "Review"; xp = 40; break;
                        case 5: category = "Assignment"; xp = 60; break;
                    }

                    user.addTask(title, category, xp);
                    System.out.println("Task added successfully! +" + xp + " XP");
                    break;

                case 2:
                    user.showTasks();
                    break;

                case 3:
                    user.showTasks();
                    System.out.print("Enter task number: ");
                    int taskNum = getInt();
                    if (taskNum == -1) {
                        System.out.println("Invalid input.");
                        break;
                    }
                    user.completeTask(taskNum - 1);
                    break;

                case 4: // Delete Task
                    user.showTasks();
                    System.out.print("Enter task number to delete: ");
                    int delNum = getInt();
                    if (delNum == -1) {
                        System.out.println("Invalid input.");
                        break;
                    }
                    user.deleteTask(delNum - 1);
                    break;

                case 5: 
                    user.showStats(); 
                    break;

                case 6: 
                    user.showBadges(); 
                    break;

                case 7: 
                    FileManager.saveTasks(user.getTasks());
                    break;

                case 8: // Exit
                    System.out.print("Are you sure you want to exit? (y/n): ");
                    String confirm = sc.nextLine().trim().toLowerCase();
                    if (confirm.equals("y")) {
                        System.out.println("Goodbye!");
                        choice = 8;
                    } else {
                        System.out.println("Cancelled.");
                    }
                    break;

                default:
                    System.out.println("Invalid choice. Please choose 1-8.");
            }

        } while (choice != 8);

        sc.close();
    }
}